import { bootYard, type Yard } from "./yard";
import { Graph } from "./graph";
import type { Command, ConsoleSnapshot, ParamValue } from "./types";

const VERSION = "yard-1";

type Slot = {
  version: string;
  yard: Yard;
};

const globalForOwnros = globalThis as typeof globalThis & {
  __ownros?: Slot;
};

export function getSession(): Yard {
  const current = globalForOwnros.__ownros;
  if (current && current.version === VERSION) return current.yard;
  current?.yard.graph.stop();
  const graph = new Graph();
  const yard = bootYard(graph);
  graph.start();
  globalForOwnros.__ownros = { version: VERSION, yard };
  return yard;
}

export function snapshot(): ConsoleSnapshot {
  const yard = getSession();
  return { ...yard.graph.snapshot(), world: yard.view() };
}

export function isCommand(value: unknown): value is Command {
  if (!value || typeof value !== "object") return false;
  const command = value as Partial<Command>;
  switch (command.type) {
    case "reset":
      return true;
    case "teleop":
      return (
        finite(command.linear) &&
        finite(command.angular) &&
        typeof command.engaged === "boolean"
      );
    case "goal":
      return finite(command.x) && finite(command.y);
    case "autonomy":
      return typeof command.enabled === "boolean";
    case "param":
      return (
        typeof command.node === "string" &&
        typeof command.name === "string" &&
        isParam(command.value)
      );
    default:
      return false;
  }
}

export function dispatch(command: Command): unknown {
  const yard = getSession();
  switch (command.type) {
    case "teleop":
      yard.publishEngaged(command.engaged);
      yard.publishTeleop(clamp(command.linear, -1.2, 1.2), clamp(command.angular, -2.4, 2.4));
      return { ok: true };
    case "goal":
      yard.publishGoal(command.x, command.y);
      return { ok: true };
    case "autonomy":
      yard.setAutonomy(command.enabled);
      return { ok: true };
    case "param":
      yard.setParam(command.node, command.name, command.value);
      return { ok: true };
    case "reset":
      return yard.reset();
    default:
      throw new Error("unknown command");
  }
}

function finite(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function isParam(value: unknown): value is ParamValue {
  return (
    typeof value === "number" ||
    typeof value === "string" ||
    typeof value === "boolean"
  );
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
