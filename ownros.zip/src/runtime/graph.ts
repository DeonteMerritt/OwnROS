import type {
  GraphSnapshot,
  LogLevel,
  ParamValue,
  QosProfile,
} from "./types";
import { QoS } from "./types";

const MAX_KEEP_ALL = 1000;
const SPIN_BUDGET = 500;

export class ServiceError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ServiceError";
  }
}

type TimerRecord = {
  period: number;
  next: number;
  callback: () => void;
  alive: boolean;
  node: string;
};

type SubscriptionRecord = {
  node: string;
  topic: string;
  qos: QosProfile;
  callback: (message: unknown) => void;
  queue: unknown[];
  alive: boolean;
};

type TopicRecord = {
  name: string;
  type: string;
  publishers: Map<string, QosProfile>;
  subscriptions: SubscriptionRecord[];
  stamps: number[];
  lastMessage: unknown;
  lastStamp: number;
};

type ServiceRecord = {
  name: string;
  type: string;
  node: string;
  handler: (request: unknown) => unknown;
};

type ParameterRecord = {
  name: string;
  value: ParamValue;
  listeners: Set<(value: ParamValue) => void>;
};

/**
 * Single-threaded graph. `publish` only enqueues. `step` and `start` run the
 * executor: one due timer, then one queued sample per subscription, repeating
 * until the graph is quiet.
 *
 * QoS is local, not networked. RELIABLE + KEEP_LAST displaces the oldest
 * unread sample. BEST_EFFORT + KEEP_LAST drops the incoming sample when the
 * reader is already at depth. KEEP_ALL retains unread samples up to a cap.
 */
export class Graph {
  private readonly nodes = new Map<string, RosNode>();
  private readonly topics = new Map<string, TopicRecord>();
  private readonly services = new Map<string, ServiceRecord>();
  private readonly timers: TimerRecord[] = [];
  private readonly logs: GraphSnapshot["log"] = [];
  private time = 0;
  private clock: ReturnType<typeof setInterval> | null = null;

  now(): number {
    return this.time;
  }

  createNode(name: string): RosNode {
    if (!name.trim()) throw new Error("node name is required");
    if (this.nodes.has(name)) throw new Error(`node ${name} already exists`);
    const node = new RosNode(this, name);
    this.nodes.set(name, node);
    return node;
  }

  getNode(name: string): RosNode | undefined {
    return this.nodes.get(name);
  }

  /** Advance sim time and run the executor. `dt` is seconds. */
  step(dt: number): void {
    if (!Number.isFinite(dt) || dt < 0) {
      throw new Error("dt must be a finite number >= 0");
    }
    this.time += dt;
    this.spin();
  }

  /** Wall-clock executor. Large stalls are clamped so physics cannot tunnel. */
  start(): void {
    if (this.clock) return;
    let last = Date.now();
    this.clock = setInterval(() => {
      const now = Date.now();
      const dt = Math.min(0.1, Math.max(0, (now - last) / 1000));
      last = now;
      this.step(dt);
    }, 25);
  }

  stop(): void {
    if (!this.clock) return;
    clearInterval(this.clock);
    this.clock = null;
  }

  snapshot(): GraphSnapshot {
    const publishersOf = new Map<string, string[]>();
    const subscribersOf = new Map<string, string[]>();
    for (const node of this.nodes.keys()) {
      publishersOf.set(node, []);
      subscribersOf.set(node, []);
    }

    const topics = [...this.topics.values()]
      .filter(
        (topic) =>
          topic.publishers.size > 0 ||
          topic.subscriptions.some((sub) => sub.alive),
      )
      .map((topic) => {
        const publishers = [...topic.publishers.keys()];
        const subscribers = unique(
          topic.subscriptions.filter((sub) => sub.alive).map((sub) => sub.node),
        );
        for (const name of publishers) publishersOf.get(name)?.push(topic.name);
        for (const name of subscribers) subscribersOf.get(name)?.push(topic.name);
        return {
          name: topic.name,
          type: topic.type,
          publishers,
          subscribers,
          hz: topic.stamps.length,
        };
      });

    const services = [...this.services.values()].map((service) => ({
      name: service.name,
      type: service.type,
      node: service.node,
    }));

    const servicesOf = new Map<string, string[]>();
    for (const service of services) {
      const list = servicesOf.get(service.node) ?? [];
      list.push(service.name);
      servicesOf.set(service.node, list);
    }

    const edges: GraphSnapshot["edges"] = [];
    for (const topic of this.topics.values()) {
      const hot = topic.lastStamp > 0 && this.time - topic.lastStamp < 0.3;
      const subscribers = unique(
        topic.subscriptions.filter((sub) => sub.alive).map((sub) => sub.node),
      );
      for (const from of topic.publishers.keys()) {
        for (const to of subscribers) {
          edges.push({ topic: topic.name, from, to, hot });
        }
      }
    }

    const echoes: Record<string, unknown> = {};
    for (const topic of this.topics.values()) {
      if (topic.lastMessage !== undefined) echoes[topic.name] = topic.lastMessage;
    }

    return {
      time: this.time,
      nodes: [...this.nodes.values()].map((node) => ({
        name: node.name,
        publishers: publishersOf.get(node.name) ?? [],
        subscribers: subscribersOf.get(node.name) ?? [],
        services: servicesOf.get(node.name) ?? [],
        parameters: node.parameterSnapshot(),
      })),
      topics,
      services,
      edges,
      log: [...this.logs],
      echoes,
    };
  }

  /** @internal */
  publish(topicName: string, message: unknown, nodeName: string): void {
    const topic = this.topics.get(topicName);
    if (!topic || !topic.publishers.has(nodeName)) {
      throw new Error(`${nodeName} does not publish ${topicName}`);
    }
    const copy = structuredClone(message);
    topic.lastMessage = summarize(copy);
    topic.lastStamp = this.time;
    topic.stamps.push(this.time);
    const cutoff = this.time - 1;
    while (topic.stamps.length > 0 && topic.stamps[0] < cutoff) {
      topic.stamps.shift();
    }

    for (const sub of topic.subscriptions) {
      if (!sub.alive) continue;
      const depth = Math.max(1, sub.qos.depth);
      if (
        sub.qos.reliability === "best_effort" &&
        sub.qos.history === "keep_last" &&
        sub.queue.length >= depth
      ) {
        continue;
      }
      sub.queue.push(structuredClone(copy));
      if (sub.qos.history === "keep_last" && sub.queue.length > depth) {
        sub.queue.shift();
      }
      if (sub.qos.history === "keep_all" && sub.queue.length > MAX_KEEP_ALL) {
        sub.queue.shift();
      }
    }
  }

  /** @internal */
  call(name: string, type: string, request: unknown): unknown {
    const service = this.services.get(name);
    if (!service) throw new ServiceError(`service ${name} is not available`);
    if (service.type !== type) {
      throw new ServiceError(`service ${name} is ${service.type}, not ${type}`);
    }
    return service.handler(structuredClone(request));
  }

  /** @internal */
  advertise(
    nodeName: string,
    topicName: string,
    type: string,
    qos: QosProfile,
  ): void {
    const topic = this.ensureTopic(topicName, type);
    topic.publishers.set(nodeName, qos);
  }

  /** @internal */
  subscribe(
    nodeName: string,
    topicName: string,
    type: string,
    qos: QosProfile,
    callback: (message: unknown) => void,
  ): SubscriptionRecord {
    const topic = this.ensureTopic(topicName, type);
    const record: SubscriptionRecord = {
      node: nodeName,
      topic: topicName,
      qos,
      callback,
      queue: [],
      alive: true,
    };
    topic.subscriptions.push(record);
    return record;
  }

  /** @internal */
  serve(
    nodeName: string,
    name: string,
    type: string,
    handler: (request: unknown) => unknown,
  ): void {
    if (this.services.has(name)) {
      throw new Error(`service ${name} already has a server`);
    }
    this.services.set(name, { name, type, node: nodeName, handler });
  }

  /** @internal */
  addTimer(nodeName: string, period: number, callback: () => void): TimerRecord {
    if (!Number.isFinite(period) || period <= 0) {
      throw new Error("timer period must be > 0");
    }
    const timer: TimerRecord = {
      period,
      next: this.time + period,
      callback,
      alive: true,
      node: nodeName,
    };
    this.timers.push(timer);
    return timer;
  }

  /** @internal */
  removeNode(name: string): void {
    for (const topic of this.topics.values()) {
      topic.publishers.delete(name);
      for (const sub of topic.subscriptions) {
        if (sub.node === name) sub.alive = false;
      }
      topic.subscriptions = topic.subscriptions.filter((sub) => sub.alive);
    }
    for (const [serviceName, service] of this.services) {
      if (service.node === name) this.services.delete(serviceName);
    }
    for (const timer of this.timers) {
      if (timer.node === name) timer.alive = false;
    }
    this.nodes.delete(name);
  }

  /** @internal */
  writeLog(node: string, level: LogLevel, message: string): void {
    this.logs.push({ time: this.time, node, level, message });
    if (this.logs.length > 80) this.logs.shift();
  }

  private ensureTopic(name: string, type: string): TopicRecord {
    const existing = this.topics.get(name);
    if (existing) {
      if (existing.type !== type) {
        throw new Error(`topic ${name} is ${existing.type}, not ${type}`);
      }
      return existing;
    }
    const topic: TopicRecord = {
      name,
      type,
      publishers: new Map(),
      subscriptions: [],
      stamps: [],
      lastMessage: undefined,
      lastStamp: 0,
    };
    this.topics.set(name, topic);
    return topic;
  }

  private spin(): void {
    let budget = SPIN_BUDGET;
    while (budget > 0) {
      const timer = this.timers.find(
        (item) => item.alive && item.next <= this.time,
      );
      if (timer) {
        timer.next += timer.period;
        if (timer.next < this.time - timer.period * 2) {
          timer.next = this.time + timer.period;
        }
        timer.callback();
        budget -= 1;
      }

      let delivered = false;
      for (const topic of this.topics.values()) {
        for (const sub of topic.subscriptions) {
          if (!sub.alive || sub.queue.length === 0) continue;
          const message = sub.queue.shift();
          sub.callback(message);
          delivered = true;
          budget -= 1;
        }
      }

      if (!timer && !delivered) break;
    }
  }
}

export class Publisher<T> {
  private alive = true;

  constructor(
    private readonly graph: Graph,
    readonly topic: string,
    readonly type: string,
    private readonly nodeName: string,
  ) {}

  publish(message: T): void {
    if (!this.alive) throw new Error(`publisher ${this.topic} is closed`);
    this.graph.publish(this.topic, message, this.nodeName);
  }

  /** @internal */
  close(): void {
    this.alive = false;
  }
}

export class ServiceClient<Request, Response> {
  constructor(
    private readonly graph: Graph,
    readonly name: string,
    readonly type: string,
  ) {}

  call(request: Request): Response {
    return this.graph.call(this.name, this.type, request) as Response;
  }
}

type Widen<T> = T extends number ? number : T extends string ? string : T extends boolean ? boolean : T;

export class Parameter<T extends ParamValue> {
  constructor(
    private readonly record: ParameterRecord,
    private readonly expected: string,
  ) {}

  get(): T {
    return this.record.value as T;
  }

  set(value: T): void {
    if (typeof value !== this.expected) {
      throw new Error(
        `parameter ${this.record.name} is ${this.expected}, not ${typeof value}`,
      );
    }
    this.record.value = value;
    for (const listener of this.record.listeners) listener(value);
  }

  onChange(listener: (value: T) => void): () => void {
    const wrapped = (value: ParamValue) => listener(value as T);
    this.record.listeners.add(wrapped);
    return () => this.record.listeners.delete(wrapped);
  }
}

export class RosNode {
  private readonly publishers: Array<Publisher<unknown>> = [];
  private readonly parameters = new Map<string, ParameterRecord>();
  private alive = true;

  constructor(
    private readonly graph: Graph,
    readonly name: string,
  ) {}

  createPublisher<T>(
    topic: string,
    type: string,
    qos: QosProfile = QoS.default,
  ): Publisher<T> {
    this.assertAlive();
    this.graph.advertise(this.name, topic, type, qos);
    const publisher = new Publisher<T>(this.graph, topic, type, this.name);
    this.publishers.push(publisher as Publisher<unknown>);
    return publisher;
  }

  createSubscription<T>(
    topic: string,
    type: string,
    callback: (message: T) => void,
    qos: QosProfile = QoS.default,
  ): void {
    this.assertAlive();
    this.graph.subscribe(this.name, topic, type, qos, (message) =>
      callback(message as T),
    );
  }

  createService<Request, Response>(
    name: string,
    type: string,
    handler: (request: Request) => Response,
  ): void {
    this.assertAlive();
    this.graph.serve(this.name, name, type, (request) =>
      handler(request as Request),
    );
  }

  createServiceClient<Request, Response>(
    name: string,
    type: string,
  ): ServiceClient<Request, Response> {
    this.assertAlive();
    return new ServiceClient(this.graph, name, type);
  }

  createTimer(period: number, callback: () => void): void {
    this.assertAlive();
    this.graph.addTimer(this.name, period, callback);
  }

  declareParameter<T extends ParamValue>(name: string, value: T): Parameter<Widen<T>> {
    this.assertAlive();
    if (this.parameters.has(name)) {
      throw new Error(`${this.name} already declared parameter ${name}`);
    }
    const record: ParameterRecord = {
      name,
      value,
      listeners: new Set(),
    };
    this.parameters.set(name, record);
    return new Parameter<Widen<T>>(record, typeof value);
  }

  getParameter<T extends ParamValue>(name: string): Parameter<T> {
    const record = this.parameters.get(name);
    if (!record) throw new Error(`${this.name} has no parameter ${name}`);
    return new Parameter<T>(record, typeof record.value);
  }

  getLogger(): {
    info: (message: string) => void;
    warn: (message: string) => void;
    error: (message: string) => void;
  } {
    return {
      info: (message) => this.graph.writeLog(this.name, "info", message),
      warn: (message) => this.graph.writeLog(this.name, "warn", message),
      error: (message) => this.graph.writeLog(this.name, "error", message),
    };
  }

  destroy(): void {
    if (!this.alive) return;
    this.alive = false;
    for (const publisher of this.publishers) publisher.close();
    this.graph.removeNode(this.name);
  }

  /** @internal */
  parameterSnapshot(): Array<{ name: string; value: ParamValue }> {
    return [...this.parameters.values()].map((parameter) => ({
      name: parameter.name,
      value: parameter.value,
    }));
  }

  private assertAlive(): void {
    if (!this.alive) throw new Error(`node ${this.name} is shut down`);
  }
}

function unique(values: string[]): string[] {
  return [...new Set(values)];
}

function summarize(value: unknown): unknown {
  if (Array.isArray(value)) {
    if (value.length > 8 && value.every((item) => typeof item === "number")) {
      const finite = value.filter((item) => Number.isFinite(item));
      return {
        length: value.length,
        min: finite.length === 0 ? null : round(Math.min(...finite)),
        max: finite.length === 0 ? null : round(Math.max(...finite)),
      };
    }
    return value.map((item) => summarize(item));
  }
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [key, item] of Object.entries(value)) {
      out[key] = summarize(item);
    }
    return out;
  }
  if (typeof value === "number") return round(value);
  return value;
}

function round(value: number): number {
  return Math.round(value * 1000) / 1000;
}
