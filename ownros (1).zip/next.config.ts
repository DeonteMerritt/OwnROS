import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // 127.0.0.1 is a different host from localhost. Dev HMR from that origin is blocked unless it is listed.
  allowedDevOrigins: ["127.0.0.1"],
};

export default nextConfig;
