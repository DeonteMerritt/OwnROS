# OwnROS

A robot runtime with the programming model of ROS 2, small enough to read in one sitting. Nodes advertise topics, subscriptions queue samples, services answer calls, and one executor drains the graph.

The process also brings up a yard: a unicycle simulator, a lidar, a navigator, and a command mux. The console is the operator node. Click the floor to send a goal, or take the stick and drive.

This is one process and an in-memory graph. It is not DDS, and it is not a drop-in for `rclpy` or `rclcpp`.

## Run

```bash
npm install
npm run dev
```

Open [http://127.0.0.1:3847](http://127.0.0.1:3847).

The graph lives in that Node process. It stays up while `npm run dev` or `npm start` is running.

```bash
npm test
npm run lint
```

## The yard graph

| Node | Publishes | Subscribes |
| --- | --- | --- |
| `operator` | `/teleop/cmd_vel`, `/operator/engaged`, `/goal` | — |
| `navigator` | `/nav/cmd_vel` | `/scan`, `/odom`, `/goal` |
| `mux` | `/cmd_vel` | `/teleop/cmd_vel`, `/nav/cmd_vel`, `/operator/engaged` |
| `simulator` | `/odom`, `/scan` | `/cmd_vel` |

`/simulator/reset` (`std_srvs/srv/Trigger`) puts the robot back on the first patrol mark. Navigator parameters `enabled`, `max_linear`, `max_angular`, and `avoid_distance` are on the `navigator` node.

While the stick or WASD is held, the mux forwards teleop. Release, and navigation resumes. Space drops the keys.

## Write a node

```ts
import { Graph } from "./src/runtime";

const graph = new Graph();
const talker = graph.createNode("talker");
const pub = talker.createPublisher<{ data: string }>(
  "/chatter",
  "std_msgs/msg/String",
);

let n = 0;
talker.createTimer(0.5, () => {
  n += 1;
  pub.publish({ data: `hello ${n}` });
});

const listener = graph.createNode("listener");
listener.createSubscription<{ data: string }>(
  "/chatter",
  "std_msgs/msg/String",
  (message) => listener.getLogger().info(message.data),
);

graph.start();
```

`publish` only enqueues. `step(dt)` or `start()` runs the executor: one due timer, then one queued sample per subscription, until the graph is quiet. Callbacks do not run inside `publish`.

QoS is local. `reliable` + `keep_last` displaces the oldest unread sample when the queue is past `depth`. `best_effort` + `keep_last` drops the incoming sample instead, which is what you want a slow reader to do with sensor data. There is no network and no retransmission.

## What maps across

| ROS 2 | OwnROS |
| --- | --- |
| Node | `graph.createNode` |
| Publisher / subscription | `createPublisher` / `createSubscription` |
| Service client / server | `createServiceClient` / `createService` |
| Parameter | `declareParameter` |
| Timer | `createTimer` |
| Executor | `graph.step` / `graph.start` |
| `ros2 topic echo` | Echo pane |
| `rqt_graph` | Graph pane |
| RViz | Yard |

Stamps use `{ sec, nanosec }`. The graph clock is seconds, advanced by the executor.

Not included: actions, lifecycle nodes, multi-process discovery, bags, or a DDS wire protocol.
