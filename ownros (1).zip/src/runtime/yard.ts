import { circleHitsAny, clamp, rayBoxes, wrapAngle } from "./geometry";
import { Graph } from "./graph";
import type {
  BoolMsg,
  LaserScan,
  Odometry,
  ParamValue,
  Pose2D,
  TriggerRequest,
  TriggerResponse,
  Twist,
  WorldView,
} from "./types";
import { QoS, timeFromSeconds, twist, zeroTwist } from "./types";

export const FIELD = {
  width: 12,
  height: 8,
  robotRadius: 0.18,
};

export const OBSTACLES = [
  { minX: 0, minY: 0, maxX: 12, maxY: 0.16 },
  { minX: 0, minY: 7.84, maxX: 12, maxY: 8 },
  { minX: 0, minY: 0, maxX: 0.16, maxY: 8 },
  { minX: 11.84, minY: 0, maxX: 12, maxY: 8 },
  { minX: 5.1, minY: 3.15, maxX: 7.1, maxY: 4.9 },
];

export const PATROL = [
  { x: 10.2, y: 2.0 },
  { x: 10.2, y: 6.2 },
  { x: 1.9, y: 6.2 },
  { x: 1.9, y: 2.0 },
];

export const START = { x: 2.1, y: 2.15, yaw: 0 };

const SIM_DT = 0.05;
const RANGE_MAX = 8;
const ANGLE_MIN = -2.2;
const ANGLE_MAX = 2.2;
const BEAMS = 49;

export type Yard = {
  graph: Graph;
  view: () => WorldView;
  publishTeleop: (linear: number, angular: number) => void;
  publishEngaged: (engaged: boolean) => void;
  publishGoal: (x: number, y: number) => void;
  setAutonomy: (enabled: boolean) => void;
  setParam: (node: string, name: string, value: ParamValue) => void;
  reset: () => TriggerResponse;
};

export function bootYard(graph: Graph): Yard {
  const pose = { ...START };
  const trail: Array<{ x: number; y: number }> = [];
  let velocity = { linear: 0, angular: 0 };
  let goal = { ...PATROL[0] };
  let goalSource: "patrol" | "operator" = "patrol";
  let patrolIndex = 0;
  let holdUntil = 0;
  let status = "Patrol 1 of 4";
  let engaged = false;
  let teleop = zeroTwist();
  let nav = zeroTwist();
  let drive = zeroTwist();
  let latestScan: LaserScan | null = null;
  let latestOdom: Odometry | null = null;

  const simulator = graph.createNode("simulator");
  const navigator = graph.createNode("navigator");
  const mux = graph.createNode("mux");
  const operator = graph.createNode("operator");

  const odomPub = simulator.createPublisher<Odometry>(
    "/odom",
    "nav_msgs/msg/Odometry",
  );
  const scanPub = simulator.createPublisher<LaserScan>(
    "/scan",
    "sensor_msgs/msg/LaserScan",
    QoS.sensor,
  );
  const navPub = navigator.createPublisher<Twist>(
    "/nav/cmd_vel",
    "geometry_msgs/msg/Twist",
  );
  const cmdPub = mux.createPublisher<Twist>("/cmd_vel", "geometry_msgs/msg/Twist");
  const teleopPub = operator.createPublisher<Twist>(
    "/teleop/cmd_vel",
    "geometry_msgs/msg/Twist",
  );
  const engagedPub = operator.createPublisher<BoolMsg>(
    "/operator/engaged",
    "std_msgs/msg/Bool",
  );
  const goalPub = operator.createPublisher<Pose2D>(
    "/goal",
    "geometry_msgs/msg/Pose2D",
  );

  const enabled = navigator.declareParameter("enabled", true);
  const maxLinear = navigator.declareParameter("max_linear", 0.75);
  const maxAngular = navigator.declareParameter("max_angular", 1.6);
  const avoidDistance = navigator.declareParameter("avoid_distance", 0.62);

  const simLog = simulator.getLogger();
  const navLog = navigator.getLogger();

  function forward(): void {
    cmdPub.publish(engaged ? teleop : nav);
  }

  mux.createSubscription<Twist>("/teleop/cmd_vel", "geometry_msgs/msg/Twist", (message) => {
    teleop = message;
    forward();
  });
  mux.createSubscription<BoolMsg>("/operator/engaged", "std_msgs/msg/Bool", (message) => {
    engaged = message.data;
    forward();
  });
  mux.createSubscription<Twist>("/nav/cmd_vel", "geometry_msgs/msg/Twist", (message) => {
    nav = message;
    forward();
  });
  simulator.createSubscription<Twist>("/cmd_vel", "geometry_msgs/msg/Twist", (message) => {
    drive = message;
  });

  navigator.createSubscription<Odometry>("/odom", "nav_msgs/msg/Odometry", (message) => {
    latestOdom = message;
  });
  navigator.createSubscription<LaserScan>(
    "/scan",
    "sensor_msgs/msg/LaserScan",
    (message) => {
      latestScan = message;
    },
    QoS.sensor,
  );
  navigator.createSubscription<Pose2D>("/goal", "geometry_msgs/msg/Pose2D", (message) => {
    goal = { x: message.x, y: message.y };
    goalSource = "operator";
    holdUntil = 0;
    status = "Driving to your goal";
    navLog.info(`goal (${message.x.toFixed(2)}, ${message.y.toFixed(2)})`);
  });

  simulator.createTimer(SIM_DT, () => {
    const linear = clamp(drive.linear.x, -1.2, 1.2);
    const angular = clamp(drive.angular.z, -2.4, 2.4);
    const yaw = pose.yaw;
    const nx = pose.x + linear * Math.cos(yaw) * SIM_DT;
    const ny = pose.y + linear * Math.sin(yaw) * SIM_DT;
    if (!circleHitsAny(nx, ny, FIELD.robotRadius, OBSTACLES)) {
      pose.x = nx;
      pose.y = ny;
    } else if (!circleHitsAny(nx, pose.y, FIELD.robotRadius, OBSTACLES)) {
      pose.x = nx;
    } else if (!circleHitsAny(pose.x, ny, FIELD.robotRadius, OBSTACLES)) {
      pose.y = ny;
    }
    pose.yaw = wrapAngle(yaw + angular * SIM_DT);
    velocity = { linear, angular };

    const last = trail[trail.length - 1];
    if (!last || Math.hypot(pose.x - last.x, pose.y - last.y) > 0.07) {
      trail.push({ x: pose.x, y: pose.y });
      if (trail.length > 320) trail.shift();
    }

    const scan = castScan(graph.now(), pose);
    odomPub.publish({
      header: { stamp: timeFromSeconds(graph.now()), frameId: "odom" },
      pose: { x: pose.x, y: pose.y, theta: pose.yaw },
      twist: twist(linear, angular),
    });
    scanPub.publish(scan);
  });

  navigator.createTimer(0.1, () => {
    if (!enabled.get()) {
      status = "Navigation off";
      navPub.publish(zeroTwist());
      return;
    }
    if (!latestOdom || !latestScan) {
      navPub.publish(zeroTwist());
      return;
    }

    const dx = goal.x - latestOdom.pose.x;
    const dy = goal.y - latestOdom.pose.y;
    const distance = Math.hypot(dx, dy);
    if (distance < 0.3) {
      if (holdUntil === 0) {
        holdUntil = graph.now() + 0.8;
        status = "Arrived";
        navLog.info(
          goalSource === "patrol"
            ? `reached patrol point ${patrolIndex + 1}`
            : "reached your goal",
        );
      }
      if (graph.now() < holdUntil) {
        navPub.publish(zeroTwist());
        return;
      }
      holdUntil = 0;
      if (goalSource === "operator") {
        goalSource = "patrol";
        navLog.info("resuming patrol");
      } else {
        patrolIndex = (patrolIndex + 1) % PATROL.length;
      }
      goal = { ...PATROL[patrolIndex] };
      status = `Patrol ${patrolIndex + 1} of ${PATROL.length}`;
      navPub.publish(zeroTwist());
      return;
    }

    const avoid = avoidDistance.get();
    const linearCap = maxLinear.get();
    const angularCap = maxAngular.get();
    const yaw = latestOdom.pose.theta;
    let ax = dx / distance;
    let ay = dy / distance;
    let nearest = Infinity;
    const { ranges, angleMin, angleIncrement } = latestScan;
    for (let i = 0; i < ranges.length; i += 1) {
      const angle = angleMin + i * angleIncrement;
      const range = ranges[i] ?? Infinity;
      if (Math.cos(angle) < 0.15) continue;
      if (range < nearest) nearest = range;
      const influence = avoid * 1.8;
      if (range >= influence) continue;
      const push = ((influence - range) / influence) ** 2;
      const worldAngle = yaw + angle;
      ax -= Math.cos(worldAngle) * push * 1.6;
      ay -= Math.sin(worldAngle) * push * 1.6;
    }

    const error = wrapAngle(Math.atan2(ay, ax) - yaw);
    const blocked = nearest < avoid;
    status = blocked
      ? goalSource === "operator"
        ? "Avoiding, toward your goal"
        : `Avoiding · patrol ${patrolIndex + 1} of ${PATROL.length}`
      : goalSource === "operator"
        ? "Driving to your goal"
        : `Patrol ${patrolIndex + 1} of ${PATROL.length}`;
    const align = clamp(1 - Math.abs(error) / 1.2, 0, 1);
    const slow = clamp(distance / 0.8, 0.3, 1);
    const clearance = clamp(nearest / (avoid * 1.3), 0.08, 1);
    const linear = blocked && nearest < avoid * 0.45 ? 0 : linearCap * (0.25 + 0.75 * align) * slow * clearance;
    const angular = clamp(error * 2.1, -angularCap, angularCap);
    navPub.publish(twist(linear, angular));
  });

  function reset(): TriggerResponse {
    pose.x = START.x;
    pose.y = START.y;
    pose.yaw = START.yaw;
    velocity = { linear: 0, angular: 0 };
    trail.length = 0;
    goal = { ...PATROL[0] };
    goalSource = "patrol";
    patrolIndex = 0;
    holdUntil = 0;
    status = "Patrol 1 of 4";
    engaged = false;
    teleop = zeroTwist();
    nav = zeroTwist();
    drive = zeroTwist();
    latestScan = null;
    latestOdom = null;
    engagedPub.publish({ data: false });
    teleopPub.publish(zeroTwist());
    navPub.publish(zeroTwist());
    simLog.info("yard reset");
    return { success: true, message: "Yard reset. Patrol starts at the south-east mark." };
  }

  simulator.createService<TriggerRequest, TriggerResponse>(
    "/simulator/reset",
    "std_srvs/srv/Trigger",
    () => reset(),
  );
  const resetClient = operator.createServiceClient<TriggerRequest, TriggerResponse>(
    "/simulator/reset",
    "std_srvs/srv/Trigger",
  );

  simLog.info("simulator up");
  navLog.info("navigator up");

  return {
    graph,
    view: () => ({
      width: FIELD.width,
      height: FIELD.height,
      robotRadius: FIELD.robotRadius,
      obstacles: OBSTACLES,
      pose: { x: pose.x, y: pose.y, yaw: pose.yaw },
      scan: latestScan
        ? {
            angleMin: latestScan.angleMin,
            angleMax: latestScan.angleMax,
            ranges: latestScan.ranges,
          }
        : null,
      goal: { ...goal },
      patrol: PATROL.map((point) => ({ ...point })),
      trail: trail.map((point) => ({ ...point })),
      engaged,
      autonomy: enabled.get(),
      status,
      velocity: { ...velocity },
    }),
    publishTeleop: (linear, angular) => {
      teleopPub.publish(twist(linear, angular));
    },
    publishEngaged: (value) => {
      engagedPub.publish({ data: value });
    },
    publishGoal: (x, y) => {
      if (
        !Number.isFinite(x) ||
        !Number.isFinite(y) ||
        x < 0.4 ||
        y < 0.4 ||
        x > FIELD.width - 0.4 ||
        y > FIELD.height - 0.4
      ) {
        throw new Error("That spot is outside the yard.");
      }
      if (circleHitsAny(x, y, FIELD.robotRadius, OBSTACLES)) {
        throw new Error("That spot is inside an obstacle.");
      }
      goalPub.publish({ x, y, theta: 0 });
    },
    setAutonomy: (value) => {
      enabled.set(value);
      if (!value) status = "Navigation off";
    },
    setParam: (nodeName, name, value) => {
      const node = graph.getNode(nodeName);
      if (!node) throw new Error(`node ${nodeName} is not in the graph`);
      node.getParameter(name).set(value);
    },
    reset: () => resetClient.call({}),
  };
}

function castScan(
  stamp: number,
  pose: { x: number; y: number; yaw: number },
): LaserScan {
  const increment = (ANGLE_MAX - ANGLE_MIN) / (BEAMS - 1);
  const ranges: number[] = [];
  for (let i = 0; i < BEAMS; i += 1) {
    const angle = ANGLE_MIN + i * increment;
    const hit = rayBoxes(
      pose.x,
      pose.y,
      Math.cos(pose.yaw + angle),
      Math.sin(pose.yaw + angle),
      OBSTACLES,
      RANGE_MAX,
    );
    ranges.push(hit < 0.05 ? 0.05 : hit);
  }
  return {
    header: { stamp: timeFromSeconds(stamp), frameId: "laser" },
    angleMin: ANGLE_MIN,
    angleMax: ANGLE_MAX,
    angleIncrement: increment,
    rangeMin: 0.05,
    rangeMax: RANGE_MAX,
    ranges,
  };
}
