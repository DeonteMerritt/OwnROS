import { describe, expect, it } from "vitest";
import { Graph, ServiceError } from "./graph";
import type { QosProfile } from "./types";

const reliable: QosProfile = {
  reliability: "reliable",
  history: "keep_last",
  depth: 2,
};

const bestEffort: QosProfile = {
  reliability: "best_effort",
  history: "keep_last",
  depth: 1,
};

describe("graph", () => {
  it("delivers talker messages to a listener on step", () => {
    const graph = new Graph();
    const talker = graph.createNode("talker");
    const listener = graph.createNode("listener");
    const pub = talker.createPublisher<{ data: string }>(
      "/chatter",
      "std_msgs/msg/String",
    );
    const heard: string[] = [];
    listener.createSubscription<{ data: string }>(
      "/chatter",
      "std_msgs/msg/String",
      (message) => heard.push(message.data),
    );
    let n = 0;
    talker.createTimer(0.5, () => {
      n += 1;
      pub.publish({ data: `hello ${n}` });
    });

    graph.step(0.5);
    graph.step(0.5);
    expect(heard).toEqual(["hello 1", "hello 2"]);
    expect(listener.getLogger()).toBeTruthy();
    const snapshot = graph.snapshot();
    expect(snapshot.topics.find((topic) => topic.name === "/chatter")?.hz).toBe(2);
    expect(snapshot.edges).toEqual([
      { topic: "/chatter", from: "talker", to: "listener", hot: true },
    ]);
  });

  it("drops the oldest unread sample for reliable keep_last", () => {
    const graph = new Graph();
    const node = graph.createNode("n");
    const pub = node.createPublisher<{ n: number }>(
      "/t",
      "std_msgs/msg/Int32",
      reliable,
    );
    const seen: number[] = [];
    node.createSubscription<{ n: number }>(
      "/t",
      "std_msgs/msg/Int32",
      (message) => seen.push(message.n),
      reliable,
    );
    for (const n of [1, 2, 3, 4]) pub.publish({ n });
    graph.step(0);
    expect(seen).toEqual([3, 4]);
  });

  it("drops incoming samples for best_effort when the reader is full", () => {
    const graph = new Graph();
    const node = graph.createNode("n");
    const pub = node.createPublisher<{ n: number }>(
      "/scan",
      "sensor_msgs/msg/LaserScan",
      bestEffort,
    );
    const seen: number[] = [];
    node.createSubscription<{ n: number }>(
      "/scan",
      "sensor_msgs/msg/LaserScan",
      (message) => seen.push(message.n),
      bestEffort,
    );
    pub.publish({ n: 1 });
    pub.publish({ n: 2 });
    pub.publish({ n: 3 });
    graph.step(0);
    expect(seen).toEqual([1]);
  });

  it("rejects a mismatched topic type", () => {
    const graph = new Graph();
    const node = graph.createNode("n");
    node.createPublisher("/chatter", "std_msgs/msg/String");
    expect(() =>
      node.createSubscription("/chatter", "std_msgs/msg/Bool", () => {}),
    ).toThrow(/std_msgs\/msg\/String/);
  });

  it("calls a service and reports a missing one", () => {
    const graph = new Graph();
    const server = graph.createNode("server");
    const client = graph.createNode("client");
    server.createService<{ value: number }, { doubled: number }>(
      "/double",
      "example/srv/Double",
      (request) => ({ doubled: request.value * 2 }),
    );
    const handle = client.createServiceClient<{ value: number }, { doubled: number }>(
      "/double",
      "example/srv/Double",
    );
    expect(handle.call({ value: 4 })).toEqual({ doubled: 8 });
    expect(() =>
      client
        .createServiceClient("/missing", "example/srv/Double")
        .call({}),
    ).toThrow(ServiceError);
  });

  it("notifies parameter listeners and shuts a node down", () => {
    const graph = new Graph();
    const node = graph.createNode("navigator");
    const speed = node.declareParameter("max_linear", 0.5);
    const seen: number[] = [];
    speed.onChange((value) => seen.push(value));
    speed.set(0.8);
    expect(speed.get()).toBe(0.8);
    expect(seen).toEqual([0.8]);
    expect(() => speed.set("fast" as unknown as number)).toThrow(/number/);

    const other = graph.createNode("other");
    const pub = other.createPublisher<{ data: string }>(
      "/chatter",
      "std_msgs/msg/String",
    );
    const heard: string[] = [];
    node.createSubscription<{ data: string }>(
      "/chatter",
      "std_msgs/msg/String",
      (message) => heard.push(message.data),
    );
    node.destroy();
    pub.publish({ data: "after" });
    graph.step(0);
    expect(heard).toEqual([]);
    expect(graph.snapshot().nodes.map((item) => item.name)).toEqual(["other"]);
  });

  it("emits a cloned sample to publish listeners", () => {
    const graph = new Graph();
    const node = graph.createNode("n");
    const pub = node.createPublisher<{ data: string }>(
      "/chatter",
      "std_msgs/msg/String",
    );
    const heard: string[] = [];
    node.createSubscription<{ data: string }>(
      "/chatter",
      "std_msgs/msg/String",
      (message) => heard.push(message.data),
    );
    const seen: string[] = [];
    const stop = graph.onPublish((event) => {
      const message = event.message as { data: string };
      seen.push(`${event.topic}:${message.data}`);
      message.data = "mutated";
    });

    pub.publish({ data: "hello" });
    graph.step(0);
    expect(seen).toEqual(["/chatter:hello"]);
    expect(heard).toEqual(["hello"]);

    stop();
    pub.publish({ data: "after" });
    expect(seen).toEqual(["/chatter:hello"]);
  });
});
