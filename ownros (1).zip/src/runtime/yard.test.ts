import { describe, expect, it } from "vitest";
import { rayBoxes } from "./geometry";
import { Graph } from "./graph";
import { bootYard, OBSTACLES, PATROL, START } from "./yard";

describe("yard", () => {
  it("sees the far wall with the lidar ray", () => {
    const distance = rayBoxes(1, 1, 1, 0, OBSTACLES, 20);
    expect(distance).toBeGreaterThan(10);
    expect(distance).toBeLessThan(11);
  });

  it("drives the patrol and can be reset", () => {
    const graph = new Graph();
    const yard = bootYard(graph);
    const goal = PATROL[0];
    let best = Infinity;

    for (let i = 0; i < 400; i += 1) {
      graph.step(0.05);
      const { pose, scan } = yard.view();
      best = Math.min(best, Math.hypot(pose.x - goal.x, pose.y - goal.y));
      if (i === 10) {
        expect(scan).not.toBeNull();
        expect(Math.min(...(scan?.ranges ?? []))).toBeLessThan(8);
      }
    }

    const traveled = Math.hypot(
      yard.view().pose.x - START.x,
      yard.view().pose.y - START.y,
    );
    expect(traveled).toBeGreaterThan(1);
    expect(best).toBeLessThan(0.45);

    const response = yard.reset();
    expect(response.success).toBe(true);
    graph.step(0.05);
    const pose = yard.view().pose;
    expect(Math.hypot(pose.x - START.x, pose.y - START.y)).toBeLessThan(0.2);
  });

  it("drives around the island to an operator goal", () => {
    const graph = new Graph();
    const yard = bootYard(graph);
    for (let i = 0; i < 8; i += 1) graph.step(0.05);
    yard.publishGoal(8.6, 4);
    let best = Infinity;
    for (let i = 0; i < 500; i += 1) {
      graph.step(0.05);
      const pose = yard.view().pose;
      best = Math.min(best, Math.hypot(pose.x - 8.6, pose.y - 4));
    }
    expect(best).toBeLessThan(0.5);
  });

  it("lets the operator take cmd_vel from the navigator", () => {
    const graph = new Graph();
    const yard = bootYard(graph);
    for (let i = 0; i < 20; i += 1) graph.step(0.05);
    const before = yard.view().pose.x;
    yard.publishEngaged(true);
    yard.publishTeleop(-0.4, 0);
    for (let i = 0; i < 40; i += 1) graph.step(0.05);
    expect(yard.view().engaged).toBe(true);
    expect(yard.view().pose.x).toBeLessThan(before);
  });
});
