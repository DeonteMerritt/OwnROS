import type { Box } from "./types";

export function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

export function wrapAngle(angle: number): number {
  let value = angle;
  while (value > Math.PI) value -= Math.PI * 2;
  while (value < -Math.PI) value += Math.PI * 2;
  return value;
}

export function circleHitsBox(
  x: number,
  y: number,
  radius: number,
  box: Box,
): boolean {
  const closestX = clamp(x, box.minX, box.maxX);
  const closestY = clamp(y, box.minY, box.maxY);
  const dx = x - closestX;
  const dy = y - closestY;
  return dx * dx + dy * dy < radius * radius;
}

export function circleHitsAny(
  x: number,
  y: number,
  radius: number,
  boxes: readonly Box[],
): boolean {
  return boxes.some((box) => circleHitsBox(x, y, radius, box));
}

/** Distance from the ray origin to the first box, or Infinity when nothing is hit. */
export function rayBoxes(
  ox: number,
  oy: number,
  dx: number,
  dy: number,
  boxes: readonly Box[],
  maxRange: number,
): number {
  let best = Infinity;
  for (const box of boxes) {
    const distance = rayBox(ox, oy, dx, dy, box, maxRange);
    if (distance < best) best = distance;
  }
  return best;
}

function rayBox(
  ox: number,
  oy: number,
  dx: number,
  dy: number,
  box: Box,
  maxRange: number,
): number {
  let tmin = 0;
  let tmax = maxRange;
  const slabs: Array<[number, number, number, number]> = [
    [ox, dx, box.minX, box.maxX],
    [oy, dy, box.minY, box.maxY],
  ];

  for (const [origin, direction, min, max] of slabs) {
    if (Math.abs(direction) < 1e-8) {
      if (origin < min || origin > max) return Infinity;
      continue;
    }
    let t1 = (min - origin) / direction;
    let t2 = (max - origin) / direction;
    if (t1 > t2) {
      const swap = t1;
      t1 = t2;
      t2 = swap;
    }
    tmin = Math.max(tmin, t1);
    tmax = Math.min(tmax, t2);
    if (tmin > tmax) return Infinity;
  }

  if (tmax < 0) return Infinity;
  if (tmin < 0) return 0;
  return tmin;
}
