/** Message, QoS, and snapshot types for the OwnROS runtime. */

export type Time = { sec: number; nanosec: number };

export type Header = {
  stamp: Time;
  frameId: string;
};

export type StringMsg = { data: string };
export type BoolMsg = { data: boolean };

export type Vector3 = { x: number; y: number; z: number };

export type Twist = {
  linear: Vector3;
  angular: Vector3;
};

export type Pose2D = { x: number; y: number; theta: number };

export type Odometry = {
  header: Header;
  pose: Pose2D;
  twist: Twist;
};

export type LaserScan = {
  header: Header;
  angleMin: number;
  angleMax: number;
  angleIncrement: number;
  rangeMin: number;
  rangeMax: number;
  ranges: number[];
};

export type TriggerRequest = Record<string, never>;

export type TriggerResponse = {
  success: boolean;
  message: string;
};

export type ParamValue = number | string | boolean;

export type LogLevel = "info" | "warn" | "error";

export type QosProfile = {
  reliability: "reliable" | "best_effort";
  history: "keep_last" | "keep_all";
  depth: number;
};

/** Presets in the same spirit as rclcpp::QoS and rmw sensor data. */
export const QoS = {
  default: {
    reliability: "reliable",
    history: "keep_last",
    depth: 10,
  },
  sensor: {
    reliability: "best_effort",
    history: "keep_last",
    depth: 5,
  },
} as const satisfies Record<string, QosProfile>;

export type Box = {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
};

export type WorldView = {
  width: number;
  height: number;
  robotRadius: number;
  obstacles: Box[];
  pose: { x: number; y: number; yaw: number };
  scan: { angleMin: number; angleMax: number; ranges: number[] } | null;
  goal: { x: number; y: number } | null;
  patrol: { x: number; y: number }[];
  trail: { x: number; y: number }[];
  engaged: boolean;
  autonomy: boolean;
  status: string;
  velocity: { linear: number; angular: number };
};

export type GraphSnapshot = {
  time: number;
  nodes: Array<{
    name: string;
    publishers: string[];
    subscribers: string[];
    services: string[];
    parameters: Array<{ name: string; value: ParamValue }>;
  }>;
  topics: Array<{
    name: string;
    type: string;
    publishers: string[];
    subscribers: string[];
    hz: number;
  }>;
  services: Array<{ name: string; type: string; node: string }>;
  edges: Array<{ topic: string; from: string; to: string; hot: boolean }>;
  log: Array<{ time: number; node: string; level: LogLevel; message: string }>;
  echoes: Record<string, unknown>;
};

export type ConsoleSnapshot = GraphSnapshot & { world: WorldView };

export type Command =
  | { type: "teleop"; linear: number; angular: number; engaged: boolean }
  | { type: "goal"; x: number; y: number }
  | { type: "autonomy"; enabled: boolean }
  | { type: "param"; node: string; name: string; value: ParamValue }
  | { type: "reset" };

export function timeFromSeconds(seconds: number): Time {
  const sec = Math.floor(seconds);
  const nanosec = Math.max(0, Math.round((seconds - sec) * 1e9));
  return { sec, nanosec };
}

export function zeroTwist(): Twist {
  return {
    linear: { x: 0, y: 0, z: 0 },
    angular: { x: 0, y: 0, z: 0 },
  };
}

export function twist(linearX: number, angularZ: number): Twist {
  return {
    linear: { x: linearX, y: 0, z: 0 },
    angular: { x: 0, y: 0, z: angularZ },
  };
}
