import { bootYard, type Yard } from "./yard";
import { Graph } from "./graph";
import type { Command, ConsoleSnapshot, ParamValue } from "./types";

/**
 * One graph for the whole Node process. Route handlers and hot-reloaded
 * modules share this slot on `globalThis`, so a new POST or SSE request
 * does not construct a second yard or a second clock.
 */
const CORE_NODES = ["operator", "navigator", "mux", "simulator"] as const;
const SESSION_VERSION = "yard-1";

/** 50Hz. The simulator timer still publishes /odom and /scan at 20Hz. */
const CLOCK_MS = 20;
const MAX_STEP_SECONDS = 0.05;

const TELEMETRY_TOPICS = new Set(["/odom", "/scan"]);

export type TelemetrySample = {
  topic: "/odom" | "/scan";
  time: number;
  message: unknown;
};

type TelemetryListener = (sample: TelemetrySample) => void;

type SessionSlot = {
  version: typeof SESSION_VERSION;
  yard: Yard;
  listeners: Set<TelemetryListener>;
  clock: ReturnType<typeof setInterval>;
};

const globalForOwnros = globalThis as typeof globalThis & {
  __ownros?: SessionSlot | { yard: Yard };
};

export function getSession(): Yard {
  return ensureSession().yard;
}

/**
 * Tap `/odom` and `/scan` as the simulator publishes them.
 * Returns an unsubscribe function. A listener that throws is removed.
 */
export function subscribeTelemetry(listener: TelemetryListener): () => void {
  const slot = ensureSession();
  slot.listeners.add(listener);
  return () => {
    slot.listeners.delete(listener);
  };
}

export function snapshot(): ConsoleSnapshot {
  const yard = getSession();
  return { ...yard.graph.snapshot(), world: yard.view() };
}

export function isCommand(value: unknown): value is Command {
  if (!value || typeof value !== "object") return false;
  const command = value as Partial<Command>;
  switch (command.type) {
    case "reset":
      return true;
    case "teleop":
      return (
        finite(command.linear) &&
        finite(command.angular) &&
        typeof command.engaged === "boolean"
      );
    case "goal":
      return finite(command.x) && finite(command.y);
    case "autonomy":
      return typeof command.enabled === "boolean";
    case "param":
      return (
        typeof command.node === "string" &&
        typeof command.name === "string" &&
        isParam(command.value)
      );
    default:
      return false;
  }
}

export function dispatch(command: Command): unknown {
  const yard = getSession();
  switch (command.type) {
    case "teleop":
      yard.publishEngaged(command.engaged);
      yard.publishTeleop(
        clamp(command.linear, -1.2, 1.2),
        clamp(command.angular, -2.4, 2.4),
      );
      return { ok: true };
    case "goal":
      yard.publishGoal(command.x, command.y);
      return { ok: true };
    case "autonomy":
      yard.setAutonomy(command.enabled);
      return { ok: true };
    case "param":
      yard.setParam(command.node, command.name, command.value);
      return { ok: true };
    case "reset":
      return yard.reset();
    default:
      throw new Error("unknown command");
  }
}

function ensureSession(): SessionSlot {
  const current = globalForOwnros.__ownros;
  if (isSessionSlot(current)) return current;

  // Drop a previous clock. `graph.stop()` only clears the interval `Graph.start` owns.
  if (current && "clock" in current && current.clock) {
    clearInterval(current.clock);
  }
  current?.yard.graph.stop();

  const graph = new Graph();
  const yard = bringUpYard(graph);
  const listeners = new Set<TelemetryListener>();

  graph.onPublish((event) => {
    if (!TELEMETRY_TOPICS.has(event.topic)) return;
    const sample: TelemetrySample = {
      topic: event.topic as TelemetrySample["topic"],
      time: event.time,
      message: event.message,
    };
    for (const listener of [...listeners]) {
      try {
        listener(sample);
      } catch {
        listeners.delete(listener);
      }
    }
  });

  let last = Date.now();
  const clock = setInterval(() => {
    const now = Date.now();
    const dt = Math.min(MAX_STEP_SECONDS, Math.max(0, (now - last) / 1000));
    last = now;
    if (dt > 0) graph.step(dt);
  }, CLOCK_MS);
  if (typeof clock === "object" && clock && "unref" in clock) {
    clock.unref();
  }

  const slot: SessionSlot = {
    version: SESSION_VERSION,
    yard,
    listeners,
    clock,
  };
  globalForOwnros.__ownros = slot;
  return slot;
}

/**
 * Bring up the yard graph: operator, navigator, mux, and simulator.
 * `bootYard` advertises their topics and services. The session clock
 * is the only executor; this does not call `graph.start()`.
 */
function bringUpYard(graph: Graph): Yard {
  const yard = bootYard(graph);
  const names = yard.graph.snapshot().nodes.map((node) => node.name).sort();
  const expected = [...CORE_NODES].sort();
  if (names.join() !== expected.join()) {
    throw new Error(`yard graph is missing core nodes: ${names.join(", ")}`);
  }
  return yard;
}

function isSessionSlot(value: unknown): value is SessionSlot {
  if (!value || typeof value !== "object") return false;
  const slot = value as Partial<SessionSlot>;
  return (
    slot.version === SESSION_VERSION &&
    slot.listeners instanceof Set &&
    slot.clock != null &&
    slot.yard != null
  );
}

function finite(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function isParam(value: unknown): value is ParamValue {
  return (
    typeof value === "number" ||
    typeof value === "string" ||
    typeof value === "boolean"
  );
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
