export function formatTime(seconds: number): string {
  const safe = Math.max(0, seconds);
  const minutes = Math.floor(safe / 60);
  const rest = safe - minutes * 60;
  return `${String(minutes).padStart(2, "0")}:${rest.toFixed(1).padStart(4, "0")}`;
}

export function formatYaw(yaw: number): string {
  const degrees = (yaw * 180) / Math.PI;
  const wrapped = ((degrees % 360) + 360) % 360;
  return `${wrapped.toFixed(0)}°`;
}

export function readSlider(value: number | readonly number[]): number {
  return typeof value === "number" ? value : (value[0] ?? 0);
}
