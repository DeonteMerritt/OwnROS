"use client";

import { useEffect, useRef } from "react";
import type { WorldView } from "@/runtime/types";

type Transform = {
  toCanvas: (x: number, y: number) => [number, number];
  toWorld: (px: number, py: number) => [number, number];
  scale: number;
};

export function fieldTransform(
  viewW: number,
  viewH: number,
  yardW: number,
  yardH: number,
): Transform {
  const pad = 22;
  const scale = Math.min((viewW - pad * 2) / yardW, (viewH - pad * 2) / yardH);
  const ox = (viewW - yardW * scale) / 2;
  const oy = (viewH - yardH * scale) / 2;
  return {
    scale,
    toCanvas(x, y) {
      return [ox + x * scale, oy + (yardH - y) * scale];
    },
    toWorld(px, py) {
      return [(px - ox) / scale, yardH - (py - oy) / scale];
    },
  };
}

export function YardView({
  world,
  onGoal,
}: {
  world: WorldView | null;
  onGoal: (x: number, y: number) => void;
}) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    const parent = canvas?.parentElement;
    if (!canvas || !parent) return;

    const paintNow = () => {
      const bounds = parent.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const width = Math.max(1, bounds.width);
      const height = Math.max(1, bounds.height);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      paint(ctx, width, height, world);
    };

    paintNow();
    const observer = new ResizeObserver(paintNow);
    observer.observe(parent);
    return () => observer.disconnect();
  }, [world]);

  return (
    <canvas
      ref={ref}
      className="h-full w-full cursor-crosshair"
      aria-label="Yard. Click an open spot to publish a goal."
      onClick={(event) => {
        const canvas = event.currentTarget;
        if (!world) return;
        const rect = canvas.getBoundingClientRect();
        const transform = fieldTransform(
          rect.width,
          rect.height,
          world.width,
          world.height,
        );
        const [x, y] = transform.toWorld(
          event.clientX - rect.left,
          event.clientY - rect.top,
        );
        onGoal(x, y);
      }}
    />
  );
}

function paint(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  world: WorldView | null,
) {
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#12170f";
  ctx.fillRect(0, 0, width, height);

  if (!world) {
    ctx.fillStyle = "#8d977f";
    ctx.font = "14px ui-monospace, monospace";
    ctx.fillText("Bringing up the yard…", 24, 40);
    return;
  }

  const transform = fieldTransform(width, height, world.width, world.height);
  const [left, top] = transform.toCanvas(0, world.height);
  const [right, bottom] = transform.toCanvas(world.width, 0);

  ctx.fillStyle = "#1a2116";
  ctx.fillRect(left, top, right - left, bottom - top);

  ctx.strokeStyle = "rgba(223, 242, 90, 0.07)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let meter = 0; meter <= world.width; meter += 1) {
    const [x] = transform.toCanvas(meter, 0);
    ctx.moveTo(x, top);
    ctx.lineTo(x, bottom);
  }
  for (let meter = 0; meter <= world.height; meter += 1) {
    const [, y] = transform.toCanvas(0, meter);
    ctx.moveTo(left, y);
    ctx.lineTo(right, y);
  }
  ctx.stroke();

  for (const box of world.obstacles) {
    const wall =
      box.minX <= 0 ||
      box.minY <= 0 ||
      box.maxX >= world.width ||
      box.maxY >= world.height;
    const [x, y] = transform.toCanvas(box.minX, box.maxY);
    const [x2, y2] = transform.toCanvas(box.maxX, box.minY);
    ctx.fillStyle = wall ? "#2a3524" : "#425233";
    ctx.fillRect(x, y, x2 - x, y2 - y);
    ctx.strokeStyle = wall ? "#3e4d34" : "rgba(223, 242, 90, 0.35)";
    ctx.strokeRect(x + 0.5, y + 0.5, x2 - x - 1, y2 - y - 1);
  }

  for (const point of world.patrol) {
    const [x, y] = transform.toCanvas(point.x, point.y);
    ctx.beginPath();
    ctx.strokeStyle = "rgba(240, 162, 2, 0.45)";
    ctx.lineWidth = 1;
    ctx.arc(x, y, 4, 0, Math.PI * 2);
    ctx.stroke();
  }

  const trail = world.trail;
  for (let i = 1; i < trail.length; i += 1) {
    const [x1, y1] = transform.toCanvas(trail[i - 1].x, trail[i - 1].y);
    const [x2, y2] = transform.toCanvas(trail[i].x, trail[i].y);
    const alpha = 0.12 + (i / trail.length) * 0.75;
    ctx.strokeStyle = `rgba(223, 242, 90, ${alpha})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
  }

  const [rx, ry] = transform.toCanvas(world.pose.x, world.pose.y);
  if (world.scan) {
    const span = world.scan.angleMax - world.scan.angleMin;
    const count = world.scan.ranges.length;
    for (let i = 0; i < count; i += 1) {
      const angle =
        world.scan.angleMin + (count === 1 ? 0 : (span * i) / (count - 1));
      const range = world.scan.ranges[i] ?? 0;
      const [hx, hy] = transform.toCanvas(
        world.pose.x + Math.cos(world.pose.yaw + angle) * range,
        world.pose.y + Math.sin(world.pose.yaw + angle) * range,
      );
      ctx.strokeStyle = "rgba(223, 242, 90, 0.16)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(rx, ry);
      ctx.lineTo(hx, hy);
      ctx.stroke();
    }
  }

  if (world.goal) {
    const [gx, gy] = transform.toCanvas(world.goal.x, world.goal.y);
    ctx.strokeStyle = "#f0a202";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(gx, gy, 10, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(gx - 14, gy);
    ctx.lineTo(gx + 14, gy);
    ctx.moveTo(gx, gy - 14);
    ctx.lineTo(gx, gy + 14);
    ctx.stroke();
  }

  const radius = Math.max(6, world.robotRadius * transform.scale);
  ctx.fillStyle = "#f4f1e6";
  ctx.beginPath();
  ctx.arc(rx, ry, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#10150e";
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.strokeStyle = "#dff25a";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(rx, ry);
  ctx.lineTo(
    rx + Math.cos(world.pose.yaw) * (radius + 10),
    ry - Math.sin(world.pose.yaw) * (radius + 10),
  );
  ctx.stroke();

  ctx.fillStyle = "#8d977f";
  ctx.font = "11px ui-monospace, monospace";
  const [lx, ly] = transform.toCanvas(0.2, 0.38);
  ctx.fillText("1 m grid", lx, ly);
}
