"use client";

import { useRef, useState } from "react";

export function Stick({
  onChange,
}: {
  onChange: (state: { x: number; y: number; active: boolean }) => void;
}) {
  const pad = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  function update(event: React.PointerEvent<HTMLDivElement>) {
    const el = pad.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const radius = rect.width / 2 - 18;
    const dx = event.clientX - (rect.left + rect.width / 2);
    const dy = event.clientY - (rect.top + rect.height / 2);
    const dist = Math.hypot(dx, dy) || 1;
    const scale = dist > radius ? radius / dist : 1;
    const x = (dx * scale) / radius;
    const y = (dy * scale) / radius;
    setKnob({ x: x * radius, y: y * radius });
    onChange({ x, y, active: true });
  }

  function release() {
    setKnob({ x: 0, y: 0 });
    onChange({ x: 0, y: 0, active: false });
  }

  return (
    <div className="flex flex-col items-center gap-2">
      <div
        ref={pad}
        className="relative size-32 touch-none rounded-full border border-border bg-background/80 sm:size-36"
        onPointerDown={(event) => {
          event.currentTarget.setPointerCapture(event.pointerId);
          update(event);
        }}
        onPointerMove={(event) => {
          if (event.currentTarget.hasPointerCapture(event.pointerId)) update(event);
        }}
        onPointerUp={release}
        onPointerCancel={release}
        role="application"
        aria-label="Drive stick. Drag to publish teleop. Release to hand control back to the navigator."
      >
        <div className="absolute inset-4 rounded-full border border-dashed border-border" />
        <div className="absolute top-1/2 left-3 right-3 h-px bg-border" />
        <div className="absolute left-1/2 top-3 bottom-3 w-px bg-border" />
        <div
          className="absolute top-1/2 left-1/2 size-10 rounded-full bg-primary shadow-[0_0_0_4px_rgba(223,242,90,0.15)]"
          style={{
            transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))`,
          }}
        />
      </div>
      <p className="font-mono text-[10px] tracking-wide text-muted-foreground uppercase">
        Stick
      </p>
    </div>
  );
}
