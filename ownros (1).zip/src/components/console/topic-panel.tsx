"use client";

import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import type { ConsoleSnapshot } from "@/runtime/types";
import { formatTime } from "./format";

export function TopicPanel({ snapshot }: { snapshot: ConsoleSnapshot }) {
  const [selected, setSelected] = useState("/cmd_vel");
  const names = snapshot.topics.map((topic) => topic.name);
  const active = names.includes(selected) ? selected : (names[0] ?? selected);
  const topic = snapshot.topics.find((item) => item.name === active);
  const echo = snapshot.echoes[active];

  return (
    <div className="flex h-full flex-col">
      <div className="px-3 py-3">
        <h2 className="font-mono text-[11px] tracking-[0.16em] text-muted-foreground uppercase">
          Topics
        </h2>
        <ul className="mt-2 flex flex-col gap-1">
          {snapshot.topics.map((item) => {
            const current = item.name === active;
            return (
              <li key={item.name}>
                <button
                  type="button"
                  onClick={() => setSelected(item.name)}
                  className={`flex w-full items-center justify-between gap-2 rounded-md border px-2 py-1.5 text-left ${
                    current
                      ? "border-primary/50 bg-primary/10"
                      : "border-transparent hover:bg-muted"
                  }`}
                >
                  <span className="min-w-0">
                    <span className="block truncate font-mono text-xs">{item.name}</span>
                    <span className="block truncate text-[10px] text-muted-foreground">
                      {item.type}
                    </span>
                  </span>
                  <Badge variant={item.hz > 0 ? "default" : "secondary"}>
                    {item.hz > 0 ? `${item.hz} Hz` : "quiet"}
                  </Badge>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
      <Separator />
      <div className="px-3 py-3">
        <h2 className="font-mono text-[11px] tracking-[0.16em] text-muted-foreground uppercase">
          Echo {topic ? topic.name : ""}
        </h2>
        <ScrollArea className="mt-2 h-48 rounded-md border border-border bg-background/50">
          <pre className="p-2 font-mono text-[11px] leading-relaxed whitespace-pre-wrap text-foreground">
            {echo === undefined
              ? "This topic has not published yet."
              : JSON.stringify(echo, null, 2)}
          </pre>
        </ScrollArea>
      </div>
      <Separator />
      <div className="px-3 py-3">
        <h2 className="font-mono text-[11px] tracking-[0.16em] text-muted-foreground uppercase">
          Services
        </h2>
        <ul className="mt-2 space-y-1">
          {snapshot.services.map((service) => (
            <li key={service.name} className="font-mono text-xs">
              <span>{service.name}</span>
              <span className="mt-0.5 block text-[10px] text-muted-foreground">
                {service.type} · {service.node}
              </span>
            </li>
          ))}
        </ul>
      </div>
      <Separator />
      <div className="min-h-0 flex-1 px-3 py-3">
        <h2 className="font-mono text-[11px] tracking-[0.16em] text-muted-foreground uppercase">
          Log
        </h2>
        <ScrollArea className="mt-2 h-36">
          <ul className="space-y-1">
            {[...snapshot.log].reverse().slice(0, 12).map((entry, index) => (
              <li key={`${entry.time}-${entry.node}-${index}`} className="font-mono text-[11px]">
                <span className="text-muted-foreground">{formatTime(entry.time)}</span>{" "}
                <span className="text-primary">{entry.node}</span> {entry.message}
              </li>
            ))}
          </ul>
        </ScrollArea>
      </div>
    </div>
  );
}
