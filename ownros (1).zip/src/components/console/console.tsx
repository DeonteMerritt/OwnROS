"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { RotateCcw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import type { Command, ConsoleSnapshot } from "@/runtime/types";
import { formatTime, formatYaw, readSlider } from "./format";
import { GraphPanel } from "./graph-panel";
import { Stick } from "./stick";
import { TopicPanel } from "./topic-panel";
import { YardView } from "./yard-view";

type Link = "connecting" | "live" | "reconnecting";

type DriveInput = {
  x: number;
  y: number;
  active: boolean;
  keys: Set<string>;
};

export function Console() {
  const { snapshot, link, error, send } = useGraph();
  const input = useRef<DriveInput>({ x: 0, y: 0, active: false, keys: new Set() });

  useEffect(() => {
    const keys = input.current.keys;
    const down = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLElement) {
        const tag = target.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA" || target.isContentEditable) return;
      }
      const key = event.key.toLowerCase();
      if (
        !["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(
          key,
        )
      ) {
        return;
      }
      event.preventDefault();
      if (key === " ") {
        keys.clear();
        return;
      }
      keys.add(key);
    };
    const up = (event: KeyboardEvent) => {
      keys.delete(event.key.toLowerCase());
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    let engaged = false;
    const id = window.setInterval(() => {
      const sample = sampleDrive(input.current);
      if (sample.engaged || engaged) {
        void send({
          type: "teleop",
          linear: sample.linear,
          angular: sample.angular,
          engaged: sample.engaged,
        });
      }
      engaged = sample.engaged;
    }, 50);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.clearInterval(id);
    };
  }, [send]);

  const world = snapshot?.world ?? null;
  const label = world?.engaged ? "Manual drive" : (world?.status ?? "Waiting for the graph");

  return (
    <div className="flex h-dvh flex-col">
      <header className="flex shrink-0 items-center justify-between gap-3 border-b px-4 py-3">
        <div className="min-w-0">
          <h1 className="text-lg leading-none font-semibold tracking-tight">OwnROS</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            A yard graph — nodes, topics, services — running in one process.
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <span className="hidden font-mono text-xs text-muted-foreground sm:inline">
            {snapshot ? formatTime(snapshot.time) : "00:00.0"}
          </span>
          <Badge variant="outline">
            {snapshot ? `${snapshot.nodes.length} nodes` : "—"}
          </Badge>
          <Badge variant={link === "live" ? "default" : "secondary"}>
            <span
              className={`size-1.5 rounded-full ${link === "live" ? "bg-primary-foreground" : "bg-muted-foreground"}`}
            />
            {link === "live" ? "live" : link === "connecting" ? "linking" : "reconnecting"}
          </Badge>
        </div>
      </header>

      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[300px_minmax(0,1fr)_340px]">
        <aside className="order-2 overflow-auto border-t lg:order-1 lg:border-t-0 lg:border-r">
          <div className="px-3 pt-3">
            <h2 className="font-mono text-[11px] tracking-[0.16em] text-muted-foreground uppercase">
              Graph
            </h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Edges brighten while messages are moving.
            </p>
          </div>
          {snapshot ? (
            <GraphPanel snapshot={snapshot} />
          ) : (
            <p className="px-3 py-6 text-sm text-muted-foreground">Waiting for nodes…</p>
          )}
        </aside>

        <section className="order-1 flex min-h-[70dvh] flex-col overflow-auto lg:order-2 lg:min-h-0">
          <div className="relative min-h-[320px] flex-1">
            <YardView
              world={world}
              onGoal={(x, y) => void send({ type: "goal", x, y })}
            />
            <div className="pointer-events-none absolute top-3 left-3 rounded-md border border-border bg-background/80 px-2.5 py-2 font-mono text-[11px] leading-relaxed backdrop-blur-sm">
              {world ? (
                <>
                  <div>
                    x {world.pose.x.toFixed(2)} y {world.pose.y.toFixed(2)} θ{" "}
                    {formatYaw(world.pose.yaw)}
                  </div>
                  <div className="text-muted-foreground">
                    v {world.velocity.linear.toFixed(2)} m/s · ω{" "}
                    {world.velocity.angular.toFixed(2)} rad/s
                  </div>
                </>
              ) : (
                <div>pose —</div>
              )}
            </div>
            <div className="absolute top-3 right-3">
              <Badge variant={world?.engaged ? "default" : "secondary"}>{label}</Badge>
            </div>
          </div>

          <div className="flex flex-col gap-4 border-t p-3 sm:flex-row sm:items-center">
            <Stick
              onChange={(state) => {
                input.current.x = state.x;
                input.current.y = state.y;
                input.current.active = state.active;
              }}
            />
            <div className="grid flex-1 gap-3">
              <ParamSlider
                label="max_linear"
                unit="m/s"
                min={0.15}
                max={1.1}
                step={0.05}
                value={param(snapshot, "navigator", "max_linear") ?? 0.75}
                onCommit={(value) =>
                  void send({ type: "param", node: "navigator", name: "max_linear", value })
                }
              />
              <ParamSlider
                label="max_angular"
                unit="rad/s"
                min={0.4}
                max={2.4}
                step={0.05}
                value={param(snapshot, "navigator", "max_angular") ?? 1.6}
                onCommit={(value) =>
                  void send({ type: "param", node: "navigator", name: "max_angular", value })
                }
              />
              <ParamSlider
                label="avoid_distance"
                unit="m"
                min={0.35}
                max={1.2}
                step={0.05}
                value={param(snapshot, "navigator", "avoid_distance") ?? 0.62}
                onCommit={(value) =>
                  void send({
                    type: "param",
                    node: "navigator",
                    name: "avoid_distance",
                    value,
                  })
                }
              />
            </div>
            <div className="flex flex-row items-center justify-between gap-3 sm:w-40 sm:flex-col sm:items-stretch">
              <label className="flex items-center justify-between gap-3 text-sm">
                <span>Autonomy</span>
                <Switch
                  checked={world?.autonomy ?? true}
                  onCheckedChange={(checked) => void send({ type: "autonomy", enabled: checked })}
                  aria-label="Autonomy"
                />
              </label>
              <Tooltip>
                <TooltipTrigger
                  render={
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => void send({ type: "reset" })}
                    >
                      <RotateCcw data-icon="inline-start" />
                      Reset yard
                    </Button>
                  }
                />
                <TooltipContent>Calls /simulator/reset</TooltipContent>
              </Tooltip>
            </div>
          </div>
          <p className="px-3 pb-3 text-xs text-muted-foreground">
            Click the floor to publish <span className="font-mono">/goal</span>. WASD or the
            arrows drive. The stick and keys publish <span className="font-mono">/teleop/cmd_vel</span>{" "}
            and take the mux until you let go. Space releases the keys.
          </p>
          {error ? (
            <p className="px-3 pb-3 text-xs text-destructive" role="status">
              {error}
            </p>
          ) : null}
        </section>

        <aside className="order-3 overflow-auto border-t lg:border-t-0 lg:border-l">
          {snapshot ? (
            <TopicPanel snapshot={snapshot} />
          ) : (
            <p className="px-3 py-6 text-sm text-muted-foreground">Waiting for topics…</p>
          )}
        </aside>
      </div>
    </div>
  );
}

function ParamSlider({
  label,
  unit,
  min,
  max,
  step,
  value,
  onCommit,
}: {
  label: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  value: number;
  onCommit: (value: number) => void;
}) {
  const [draft, setDraft] = useState<number | null>(null);
  const shown = draft ?? value;
  return (
    <label className="grid gap-1.5">
      <span className="flex items-center justify-between font-mono text-[11px] text-muted-foreground">
        <span>{label}</span>
        <span className="text-foreground">
          {shown.toFixed(2)} {unit}
        </span>
      </span>
      <Slider
        min={min}
        max={max}
        step={step}
        value={[shown]}
        onValueChange={(next) => setDraft(readSlider(next))}
        onValueCommitted={(next) => {
          onCommit(readSlider(next));
          setDraft(null);
        }}
      />
    </label>
  );
}

function param(
  snapshot: ConsoleSnapshot | null,
  nodeName: string,
  name: string,
): number | null {
  const node = snapshot?.nodes.find((item) => item.name === nodeName);
  const parameter = node?.parameters.find((item) => item.name === name);
  return typeof parameter?.value === "number" ? parameter.value : null;
}

function sampleDrive(input: DriveInput): {
  linear: number;
  angular: number;
  engaged: boolean;
} {
  if (input.active) {
    return {
      linear: clamp(-input.y, -1, 1) * 0.9,
      angular: clamp(-input.x, -1, 1) * 1.5,
      engaged: true,
    };
  }
  let linear = 0;
  let angular = 0;
  if (input.keys.has("w") || input.keys.has("arrowup")) linear += 0.7;
  if (input.keys.has("s") || input.keys.has("arrowdown")) linear -= 0.45;
  if (input.keys.has("a") || input.keys.has("arrowleft")) angular += 1.2;
  if (input.keys.has("d") || input.keys.has("arrowright")) angular -= 1.2;
  return { linear, angular, engaged: linear !== 0 || angular !== 0 };
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function useGraph() {
  const [snapshot, setSnapshot] = useState<ConsoleSnapshot | null>(null);
  const [link, setLink] = useState<Link>("connecting");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const source = new EventSource("/api/stream");
    source.onopen = () => setLink("live");
    source.onerror = () => setLink("reconnecting");
    source.onmessage = (event) => {
      try {
        setSnapshot(JSON.parse(event.data) as ConsoleSnapshot);
        setLink("live");
      } catch {
        setLink("reconnecting");
      }
    };
    return () => source.close();
  }, []);

  const send = useCallback(async (command: Command) => {
    try {
      const response = await fetch("/api/command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(command),
      });
      const body = (await response.json()) as { error?: string };
      if (!response.ok) {
        setError(body.error ?? "Command failed.");
        return;
      }
      setError(null);
    } catch {
      setError("Could not reach the graph.");
    }
  }, []);

  return { snapshot, link, error, send };
}
