"use client";

import { useLayoutEffect, useRef, useState } from "react";
import type { ConsoleSnapshot } from "@/runtime/types";

const ORDER = ["operator", "mux", "simulator", "navigator"];

const BLURB: Record<string, string> = {
  operator: "Stick, keys, and goals",
  mux: "Teleop wins while you hold",
  simulator: "Unicycle, odom, lidar",
  navigator: "Patrol and avoidance",
};

type Box = { x: number; y: number; w: number; h: number };

export function GraphPanel({ snapshot }: { snapshot: ConsoleSnapshot }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [boxes, setBoxes] = useState<Record<string, Box>>({});

  const nodes = [...snapshot.nodes].sort((a, b) => rank(a.name) - rank(b.name));
  const signature = nodes.map((node) => node.name).join("|");

  useLayoutEffect(() => {
    const root = containerRef.current;
    if (!root) return;
    const measure = () => {
      const rootBox = root.getBoundingClientRect();
      const next: Record<string, Box> = {};
      for (const node of nodes) {
        const el = cardRefs.current[node.name];
        if (!el) continue;
        const rect = el.getBoundingClientRect();
        next[node.name] = {
          x: rect.left - rootBox.left,
          y: rect.top - rootBox.top,
          w: rect.width,
          h: rect.height,
        };
      }
      setBoxes((prev) => (sameBoxes(prev, next) ? prev : next));
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(root);
    return () => observer.disconnect();
  }, [signature, snapshot.time, nodes]);

  return (
    <div ref={containerRef} className="relative px-3 py-3">
      <svg className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden>
        {snapshot.edges.map((edge, index) => {
          const from = boxes[edge.from];
          const to = boxes[edge.to];
          if (!from || !to) return null;
          const x1 = from.x;
          const y1 = from.y + from.h / 2;
          const x2 = to.x;
          const y2 = to.y + to.h / 2;
          const lane = 16 + (index % 5) * 8;
          const path = `M ${x1} ${y1} C ${x1 - lane} ${y1}, ${x2 - lane} ${y2}, ${x2} ${y2}`;
          const color = edge.hot ? topicColor(edge.topic) : "rgba(141, 151, 127, 0.45)";
          return (
            <g key={`${edge.from}-${edge.topic}-${edge.to}`}>
              <title>{edge.topic}</title>
              <path
                d={path}
                fill="none"
                stroke={color}
                strokeWidth={edge.hot ? 2 : 1}
              />
            </g>
          );
        })}
      </svg>
      <div className="relative ml-16 flex flex-col gap-3">
        {nodes.map((node) => (
          <div
            key={node.name}
            ref={(el) => {
              cardRefs.current[node.name] = el;
            }}
            className="rounded-md border border-border bg-card/90 px-3 py-2"
          >
            <div className="flex items-baseline justify-between gap-2">
              <h3 className="font-mono text-sm text-foreground">{node.name}</h3>
              <span className="font-mono text-[10px] text-muted-foreground">
                {node.publishers.length} out · {node.subscribers.length} in
              </span>
            </div>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {BLURB[node.name] ?? "Node"}
            </p>
            {node.publishers.length > 0 ? (
              <p className="mt-1 truncate font-mono text-[10px] text-primary/80">
                {node.publishers.join("  ")}
              </p>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  );
}

function rank(name: string): number {
  const index = ORDER.indexOf(name);
  return index === -1 ? ORDER.length : index;
}

function sameBoxes(a: Record<string, Box>, b: Record<string, Box>): boolean {
  const keys = Object.keys(a);
  if (keys.length !== Object.keys(b).length) return false;
  return keys.every((key) => {
    const left = a[key];
    const right = b[key];
    return (
      left &&
      right &&
      left.x === right.x &&
      left.y === right.y &&
      left.w === right.w &&
      left.h === right.h
    );
  });
}

function topicColor(topic: string): string {
  const colors = ["#dff25a", "#8fd9c4", "#f0a202", "#ff8b6a", "#d7c4ff"];
  let hash = 0;
  for (const char of topic) hash = (hash * 33 + char.charCodeAt(0)) >>> 0;
  return colors[hash % colors.length] ?? colors[0];
}
