export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { getSession } = await import("./runtime/session");
    getSession();
  }
}
