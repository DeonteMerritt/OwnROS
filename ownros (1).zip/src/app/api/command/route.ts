import { dispatch, isCommand } from "@/runtime/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Expected a JSON command." }, { status: 400 });
  }
  if (!isCommand(body)) {
    return Response.json({ error: "Unknown command." }, { status: 400 });
  }
  try {
    return Response.json(dispatch(body));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Command failed.";
    return Response.json({ error: message }, { status: 400 });
  }
}
