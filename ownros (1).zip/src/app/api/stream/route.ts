import { snapshot, subscribeTelemetry, type TelemetrySample } from "@/runtime/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Live stream for one browser.
 * `event: sample` is each `/odom` and `/scan` publication.
 * Unnamed `data:` frames are console snapshots so the yard view can paint
 * the rest of the graph without polling.
 */
export function GET() {
  const encoder = new TextEncoder();
  let closed = false;
  let unsubscribe = () => {};
  let snapshotTimer: ReturnType<typeof setInterval> | undefined;

  const cleanup = () => {
    if (closed) return;
    closed = true;
    unsubscribe();
    if (snapshotTimer !== undefined) clearInterval(snapshotTimer);
    snapshotTimer = undefined;
  };

  const stream = new ReadableStream({
    start(controller) {
      const send = (frame: string) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(frame));
        } catch {
          cleanup();
        }
      };

      unsubscribe = subscribeTelemetry((sample: TelemetrySample) => {
        send(`event: sample\ndata: ${JSON.stringify(sample)}\n\n`);
      });

      const sendSnapshot = () => {
        send(`data: ${JSON.stringify(snapshot())}\n\n`);
      };
      sendSnapshot();
      snapshotTimer = setInterval(sendSnapshot, 100);
    },
    cancel() {
      cleanup();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
